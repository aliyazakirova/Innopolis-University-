import React, { useState } from 'react';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
import { styled } from '@mui/system';

const StyledBox = styled(Box)({
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: '80%',
  maxWidth: 400,
  backgroundColor: '#ffffff', // Adjust background color as needed
  boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.15)', // Adjust box shadow as needed
  padding: '32px',
  borderRadius: '8px', // Adjust border radius as needed
  textAlign: 'center',
});

function BasicModal() {
  const [open, setOpen] = useState(false);

  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  return (
    <div>
      <Button variant="contained" onClick={handleOpen}>Открыть модальное окно</Button>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <StyledBox>
          <Typography variant="h6" component="h2" gutterBottom>
            Скидки
          </Typography>
          <Typography variant="body1">
            Скидки 50% на всю зимнюю коллекцию!
          </Typography>
          <Button variant="contained" color="primary" onClick={handleClose} style={{ marginTop: '16px' }}>
            Закрыть
          </Button>
        </StyledBox>
      </Modal>
    </div>
  );
}

function App() {
  return (
    <div className="App">
      <BasicModal />
    </div>
  );
}

export default App;
